#!/bin/bash
# Sombra Madrid — double-click this file to run the app.
#
# The page has to be served over HTTP: browsers block a file:// page from
# calling the live data services, so opening index.html directly gives you a
# map with no streets, no heights and no address search.

cd "$(dirname "$0")" || exit 1

# Find a free port, so an already-running server doesn't collide with this one.
PORT=8080
while lsof -nP -iTCP:"$PORT" -sTCP:LISTEN >/dev/null 2>&1; do
  PORT=$((PORT + 1))
  if [ "$PORT" -gt 8099 ]; then
    echo "Ports 8080-8099 are all busy. Close whatever is using them and try again."
    read -r -p "Press Return to close this window. "
    exit 1
  fi
done

URL="http://127.0.0.1:$PORT"

# Ruby ships with macOS. python3 is only a stub until the Xcode command line
# tools are installed, so it is tried second to avoid triggering that prompt.
if command -v ruby >/dev/null 2>&1; then
  SERVER=(ruby -run -e httpd . -b 127.0.0.1 -p "$PORT")
elif command -v python3 >/dev/null 2>&1 && python3 -c "" >/dev/null 2>&1; then
  SERVER=(python3 -m http.server "$PORT" --bind 127.0.0.1)
elif command -v php >/dev/null 2>&1; then
  SERVER=(php -S "127.0.0.1:$PORT")
else
  echo "No ruby, python3 or php found, so this folder cannot be served."
  read -r -p "Press Return to close this window. "
  exit 1
fi

echo ""
echo "  Sombra Madrid is running at $URL"
echo "  Leave this window open while you use it."
echo "  Press Control-C here to stop the server."
echo ""

# Give the server a moment to bind, then open a browser.
(
  sleep 1
  if command -v open >/dev/null 2>&1; then
    open "$URL"
  elif command -v xdg-open >/dev/null 2>&1; then
    xdg-open "$URL"
  else
    echo "Open $URL in your browser."
  fi
) &

"${SERVER[@]}"
